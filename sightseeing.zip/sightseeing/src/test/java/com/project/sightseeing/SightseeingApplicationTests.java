package com.project.sightseeing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SightseeingApplicationTests {

	@Test
	void contextLoads() {
	}

}
