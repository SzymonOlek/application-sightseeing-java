package com.project.sightseeing.Ban;

public enum Ban_type {coment_ban, perma_ban;
	
	
}
