package com.project.sightseeing.Ban;

public enum Ban_type {
	comment_ban, perma_ban;
	
	
}
