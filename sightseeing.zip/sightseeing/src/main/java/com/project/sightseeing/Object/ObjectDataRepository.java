package com.project.sightseeing.Object;

import org.springframework.data.repository.CrudRepository;

public interface ObjectDataRepository extends CrudRepository<ObjectData, Integer>{

}
