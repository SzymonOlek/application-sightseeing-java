package com.project.sightseeing.Commentary;

import org.springframework.data.repository.CrudRepository;

public interface CommentaryDataRepository extends CrudRepository<CommentaryData, Integer>{

}
