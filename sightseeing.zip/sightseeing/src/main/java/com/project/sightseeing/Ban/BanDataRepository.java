package com.project.sightseeing.Ban;

import org.springframework.data.repository.CrudRepository;

public interface BanDataRepository extends CrudRepository<BanData, Integer>{

}
