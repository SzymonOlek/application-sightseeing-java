package com.project.sightseeing.Others;

public class Values{
 public int Int;

// public Values() {
//	 Int = 5;
// }
 
public int getInt() {
	return Int;
}

public void setInt(int i) {
	Int = i;
}
}
