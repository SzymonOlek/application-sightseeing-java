package com.project.sightseeing.Others;

public class Values{
 public int Int;

public int getInt() {
	return Int;
}

public void setInt(int i) {
	Int = i;
}
}
