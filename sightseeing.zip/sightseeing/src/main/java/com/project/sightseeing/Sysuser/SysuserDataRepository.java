package com.project.sightseeing.Sysuser;

import org.springframework.data.repository.CrudRepository;

public interface SysuserDataRepository extends CrudRepository<SysuserData, Integer> {

}