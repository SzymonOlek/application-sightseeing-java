package com.project.sightseeing.Admin;

public class CorThread {
	public String nick;
	public int id;
	public CorThread() {
		this.nick = new String();
		this.id = -1;
	}
	public CorThread(int id) {
		this.nick = new String();
		this.id = id;
	}
}
