package com.project.sightseeing.City;

import org.springframework.data.repository.CrudRepository;

public interface CityDataRepository extends CrudRepository<CityData, Integer>{

}
