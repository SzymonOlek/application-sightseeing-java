package com.project.sightseeing.Commentary;

public enum Rate {one, two, three, four, five

}
