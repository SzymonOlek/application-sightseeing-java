package com.project.sightseeing.Route;

import org.springframework.data.repository.CrudRepository;

public interface RouteDataRepository extends CrudRepository<RouteData, Integer>{

}
