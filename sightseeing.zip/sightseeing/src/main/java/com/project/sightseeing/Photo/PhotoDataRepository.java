package com.project.sightseeing.Photo;

import org.springframework.data.repository.CrudRepository;

public interface PhotoDataRepository extends CrudRepository<PhotoData, Integer>{

}
