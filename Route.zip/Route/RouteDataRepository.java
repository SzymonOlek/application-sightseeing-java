package com.project.sightseeing.Route;

//import java.util.Collection;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;




public interface RouteDataRepository extends CrudRepository<RouteData, Integer>{
	
}
	
	

