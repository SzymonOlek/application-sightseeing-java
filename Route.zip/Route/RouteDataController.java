package com.project.sightseeing.Route;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringJoiner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.project.sightseeing.Object.ObjectData;



@Controller
@RequestMapping(path = "/route")
public class RouteDataController {
	@Autowired
	RouteDataRepository routeRepo;
	
	@PostMapping(path = "/add")
	public @ResponseBody String addRoute(@ModelAttribute RouteData routeToAdd) {
		
//		RouteData r = new RouteData();
		
		routeToAdd.setRoute_id((int)routeRepo.count() + 1);
//		r.setCity_id(city_id);
//		r.setObject_1_id(object_1_id);
//		r.setObject_2_id(object_2_id);
//		r.setDistance(distance);
		
		routeRepo.save(routeToAdd);
		getAllFromDataBase();
		return "Route saved.";
	}
	
	@GetMapping(path = "/all")
	public String getRoutes(Model model){
		model.addAttribute("routes", routeRepo.findAll());
		getAllFromDataBase();
		return "routedata";
	}
	@GetMapping(path = "/add")
	public String addRoutes(Model model){
		model.addAttribute("route", new RouteData());
	getAllFromDataBase();
		return "formroute";
	}
	
	
	
	public LinkedList<RouteData> getAllFromDataBase() {
	
		LinkedList<RouteData> list=new LinkedList<>();
		Iterable<RouteData> result =routeRepo.findAll();

		for(RouteData x:result ) {
			list.add(x);
		}
		for(int i = 0;i < list.size(); i++) {
			System.out.println(list.get(i));
		}
		System.out.println("wypisujemy tablice111222");
		distanceTable(list);
		return list;
		
	}


	
	
//to mogłoby być w nowej klasie ale nie umiem jej zrobić XD


    public int[][] distanceTable(LinkedList<RouteData> routeDataLinkedList) {
    	System.out.println("wypisujemy tablice");

        routeDataLinkedList.sort(this::compare);        //teraz powinno byc już posortowane

        int size = (int) Math.sqrt(routeDataLinkedList.size());

        int[][] distanceTable = new int[size][size];
        if(size*size!=routeDataLinkedList.size()){
            throw  new IllegalArgumentException();
        }

        for (int i = 0; i < size; i++) {
            for (int t = 0; t < size; t++) {
                distanceTable[i][t] = Math.round(routeDataLinkedList.remove().getDistance());
            }
        }
        
//        for(int i = 0; i<distanceTable.length; i++) {
//        	for(int j = 0; j< distanceTable [i].length; j++) {
//        		System.out.print(distanceTable[i][j]);
//        	}
//        	System.out.println();
//  }
        return distanceTable;
    }


    //1 if x>y  -1 if x<y
    public int compare(RouteData x, RouteData y) {

        if (x.getObject_1_id() > y.getObject_1_id()) {    //x>y
            return 1;
        }
        if (x.getObject_1_id() < y.getObject_1_id()) {          //y>x
            return -1;
        }
        if (x.getObject_1_id() == y.getObject_1_id()) {
            if (x.getObject_2_id() > y.getObject_2_id()) {          //x>y
                return 1;
            } else if (x.getObject_2_id() < y.getObject_2_id()) {           //y>x
                return -1;
            }
        }


        return -1;
    }
    
    public String give_route() {
		Algorythm algorythm = new Algorythm();
		int [][] distance = distanceTable(getAllFromDataBase());	
		algorythm.minCost(distance);
    	return algorythm.GetLastTrace();
    	
    }
    


}



